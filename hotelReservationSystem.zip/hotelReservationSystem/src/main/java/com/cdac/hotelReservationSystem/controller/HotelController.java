package com.cdac.hotelReservationSystem.controller;

import com.cdac.hotelReservationSystem.dto.ReservationRequest;
import com.cdac.hotelReservationSystem.entity.Reservation;
import com.cdac.hotelReservationSystem.entity.Room;
import com.cdac.hotelReservationSystem.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hotel")
public class HotelController {

    @Autowired
    private HotelService hotelService;

    // Create Reservation
//    @PostMapping("/reservations")
//    public ResponseEntity<Reservation> createReservation(@RequestBody Reservation reservation) {
//        Reservation createdReservation = hotelService.createReservation(reservation);
//        return new ResponseEntity<>(createdReservation, HttpStatus.CREATED);
//    }
    // Create Reservation
    @PostMapping("/reservations")
    public ResponseEntity<Reservation> createReservation(@RequestBody ReservationRequest reservationRequest) {
        // Create Reservation object and set the fields
        Reservation reservation = new Reservation();
        reservation.setGuestName(reservationRequest.getGuestName());
        reservation.setCheckInDate(reservationRequest.getCheckInDate());
        reservation.setCheckOutDate(reservationRequest.getCheckOutDate());

        // Fetch the room using the roomId from the request
        Room room = hotelService.getRoomById(reservationRequest.getRoomId());

//        if (room == null || !room.getAvailability()) {
//            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Room is not available
//        }

        // Set the room and calculate the total price
        reservation.setRoom(room);
        reservation.setTotalPrice(room.getPrice() * reservationRequest.getTotalNights());

        // Mark the room as unavailable
        room.setAvailability(false);
        hotelService.updateRoomAvailability(room);

        // Save the reservation
        Reservation createdReservation = hotelService.createReservation(reservation);

        return new ResponseEntity<>(createdReservation, HttpStatus.CREATED);
    }
    // Get Available Rooms
    @GetMapping("/rooms/available")
    public ResponseEntity<List<Room>> getAvailableRooms() {
        List<Room> availableRooms = hotelService.getAvailableRooms();
        return new ResponseEntity<>(availableRooms, HttpStatus.OK);
    }

    // Cancel Reservation
    @DeleteMapping("/reservations/{reservationId}")
    public ResponseEntity<String> cancelReservation(@PathVariable Long reservationId) {
        hotelService.cancelReservation(reservationId);
        return new ResponseEntity<>("Reservation cancelled successfully", HttpStatus.OK);
    }
}

