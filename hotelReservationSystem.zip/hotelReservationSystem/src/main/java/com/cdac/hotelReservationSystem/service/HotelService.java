package com.cdac.hotelReservationSystem.service;

import com.cdac.hotelReservationSystem.entity.Reservation;
import com.cdac.hotelReservationSystem.entity.Room;
import com.cdac.hotelReservationSystem.exceptions.ReservationNotFoundException;
import com.cdac.hotelReservationSystem.exceptions.RoomNotFoundException;
import com.cdac.hotelReservationSystem.repository.ReservationRepository;
import com.cdac.hotelReservationSystem.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HotelService {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    // Create Reservation
    public Reservation createReservation(Reservation reservation) {
        Room room = reservation.getRoom();
        room.setAvailability(false); // Mark room as unavailable
        roomRepository.save(room);
        return reservationRepository.save(reservation);
    }

    // Get Available Rooms
    public List<Room> getAvailableRooms() {
        return roomRepository.findByAvailabilityTrue();
    }

    // Cancel Reservation
    public void cancelReservation(Long reservationId) {
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ReservationNotFoundException("Reservation not found"));
        Room room = reservation.getRoom();
        room.setAvailability(true); // Mark room as available
        roomRepository.save(room);
        reservationRepository.delete(reservation);
    }
    public Room getRoomById(Long roomId) {
        return roomRepository.findById(roomId)
                .orElseThrow(() -> new RoomNotFoundException("Room not found"));
    }
    public void updateRoomAvailability(Room room) {
        roomRepository.save(room);
    }
}
